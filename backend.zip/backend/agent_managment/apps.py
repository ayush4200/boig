from django.apps import AppConfig


class AgentManagmentConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "agent_managment"
